from string import ascii_lowercase, ascii_uppercase, digits, punctuation

import tkinter as tk

from PIL import Image

import customtkinter as CTk

import secrets

class Pass(CTk.CTk):
    def __init__(self):
        super().__init__()
        self.geometry("430x200")
        self.title("Add Password")
        self.resizable(False,False)
    def __init__(self) -> None:
        super().__init__()

        self.geometry("430x260")
        self.title("Pass manager")
        self.resizable(False,False)

        self.button_frame = CTk.CTkFrame(master=self, fg_color="#343a40",border_width=0,corner_radius=0)
        self.button_frame.grid(row=0,column=0,sticky="nsew",padx=(5,5),pady=(5,5))

        self.button_addNewPass = CTk.CTkButton(master=self.button_frame,text="Add New Password",width=200,command=self.addPass)
        self.button_addNewPass.grid(row=0,column=0,padx=(5),pady=(5))

        self.button_Settings = CTk.CTkButton(master=self.button_frame,text="Settings",width=200,)
        self.button_Settings.grid(row=0,column=1,padx=(5),pady=(5))

        self.pass_list = CTk.CTkFrame(master=self,fg_color="#343a40")
        self.pass_list.grid(row=1,column=0,sticky="nsew",padx=(5,5),pady=(5,5))
    
def addPass():
    new = Pass()
    new.mainloop()
addPass()