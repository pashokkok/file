import os
import requests
import time
import win32api
from urllib.parse import urlencode
from bs4 import BeautifulSoup
import shutil
from pathlib import Path
from zipfile import ZipFile

version = '1.4'

os.system('cls')
B = '\u0040\u006C\u0061\u006D\u0065\u0072\u0031\u0031\u0032\u0033\u0031\u0031' #blue
R = '\033[31m' # red
G = '\033[32m' # green
C = '\033[36m' # cyan
W = '\033[0m'  # white
P = '\033[35m'  # purple
sk = '\U0001f480'

def end(github_ver3, dest):
	print(f'У вас установлена актуальная версия: {github_ver3}')
	print('Установщик закроется через 5 секунд.')
	shutil.rmtree(dest)
	time.sleep(5)
	exit()

def updater(current_dir, github_ver4):
	print(f'Installing HelUpdater_v{github_ver4}.exe ')
	time.sleep(1.5)
	base_url = 'https://cloud-api.yandex.net/v1/disk/public/resources/download?'
	public_key = 'https://disk.yandex.ru/d/bYNe5VJYf-9WTw'

	final_url = base_url + urlencode(dict(public_key=public_key))
	response = requests.get(final_url)
	download_url = response.json()['href']
	download_response = requests.get(download_url)
	with open(f'{current_dirI}\\HelUpdater_{github_ver4}.exe', 'wb') as f:
		f.write(download_response.content)
		f.close()
	print(f'Installing HelUpdater_v{github_ver4}.exe | Successful')
	print(f'Trying to start HelUpdater_v{github_ver4}.exe')
	time.sleep(2)
	try:
		os.system(f'start HelUpdater_v{github_ver4}.exe')
		exit()
	except:
		print(f'Cannot find HelUpdater_v{github_ver4}.exe')
def download(minePath, full_name, dest, github_ver3):
	print(f'Installing HELL_RP-V {github_ver3}')
	time.sleep(1.5)
	base_url = 'https://cloud-api.yandex.net/v1/disk/public/resources/download?'
	public_key = 'https://disk.yandex.ru/d/b8c48GCBBueoVQ'

	final_url = base_url + urlencode(dict(public_key=public_key))
	response = requests.get(final_url)
	download_url = response.json()['href']
	download_response = requests.get(download_url)
	with open(f'{minePath}\\{full_name}.zip', 'wb') as f:
		f.write(download_response.content)
		f.close()
	print(f'Installing HELL_RP-V {github_ver3} | Successful')
	print('Установщик закроется через 5 секунд.')
	time.sleep(5)
	exit()
def version_checker(minePath, full_name, dest):
	minePathFull = minePath+'\\HELL_RP.zip'
	ver_url2 = 'https://raw.githubusercontent.com/pashokkok/ver/main/version.txt'
	ver_rqst2 = requests.get(ver_url2)
	ver_sc2 = ver_rqst2.status_code
	if ver_sc2 == 200:
		github_ver2 = ver_rqst2.text
		github_ver3 = github_ver2.strip()
		
		try:
			shutil.copy2(minePathFull, dest)
		except:	
			pass
		with ZipFile(dest+"\\HELL_RP.zip", "r") as myzip:
			myzip.extractall(path=dest, members=["pack.mcmeta"])
		with open(dest+"\\pack.mcmeta", "r") as f:
			text=f.read()
			if github_ver3 in text:
				f.close()
				return end(github_ver3, dest)
			else:
				download(minePath, full_name, dest, github_ver3)
if __name__ == "__main__":
	def ver_check():
		ver_url3 = 'https://raw.githubusercontent.com/pashokkok/ver2/main/version.txt'
		ver_rqst3 = requests.get(ver_url3)
		ver_sc3 = ver_rqst3.status_code
		current_dirI = Path.cwd()
		if ver_sc3 == 200:
			github_ver3 = ver_rqst3.text
			github_ver4 = github_ver3.strip()
			if version == github_ver4:
				pass
			else:
				print(f'[{version}] Версия установщика не актуальна.')
				print(f'Актуальная версия: {github_ver4}')
				return updater(github_ver4, current_dirI)
	ver_check()
	appdataPath = os.environ.get('USERPROFILE') + "\\AppData"

	os.system("mode con cols=89 lines=15")
	win32api.SetConsoleTitle(f'HELL Installer {sk} Latest Version: unknown')

	minePath = appdataPath+"\\Roaming\\.minecraft\\resourcepacks"
	current_dir = Path.cwd()
	dest = (str(current_dir)+'\\version')

	full_name = 'HELL_RP'
	try:
		os.mkdir('version')
	except:
		pass
	version_checker(minePath, full_name, dest)